// validation Game
document.addEventListener("DOMContentLoaded", function () {
  const popupWrapper = document.getElementById("popupWrapper");
  const close = document.getElementById("close");
  const gameForm = document.getElementById("player-list-container");

  gameForm.addEventListener("submit", function (event) {
    event.preventDefault();

    // Get the player names and card options
    const player1Input = document.getElementById("player1");
    const player2Input = document.getElementById("player2");
    const player1Name = player1Input.value;
    const player2Name = player2Input.value;

    // Get the selected values
    const cardOptionsSelect = document.getElementById("card-options");
    const cardOption = cardOptionsSelect.value;

    // Perform validation
    if (
      player1Name.trim() === "" ||
      player2Name.trim() === "" ||
      cardOption === ""
    ) {
      // Display an error message or prevent the game from starting
      console.log("Please fill in all the required fields.");
      return;
    }

    // If the form is valid, you can perform any necessary actions, such as starting the game
    console.log(
      "Starting the game with player names:",
      player1Name,
      player2Name
    );
    console.log("Card option selected:", cardOption);

  
  });

  // Show the popup by default
  popupWrapper.style.display = "block";

  // Add event listener to close the popup
  close.addEventListener("click", function () {
    popupWrapper.style.display = "none";
  });
});
